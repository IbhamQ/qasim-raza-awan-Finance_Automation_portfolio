"""Independent checks against the exported ledger, not the Power BI model."""
import csv,json
from pathlib import Path
from decimal import Decimal as D
from collections import Counter
root=Path(__file__).parent
def read(name):return list(csv.DictReader((root/'data'/(name+'.csv')).open(encoding='utf-8')))
orders=read('Orders');budget=read('Budget');flags=read('Flags')
expected=json.loads((root/'expected_results.json').read_text())
assert len(orders)==7200==expected['orders']
assert len({r['Order ID'] for r in orders})==len(orders)
assert len({r['Month key'] for r in orders})==18
flagset={(r['Order ID'],r['Rule']) for r in flags}
assert len(flagset)==len(flags)
net=D(0);contribution=D(0);losses=0;flagged=0
for r in orders:
    assert 1<=int(r['Product key'])<=12 and 1<=int(r['Region key'])<=4 and 1<=int(r['Channel key'])<=3
    g,disc,ref,n,c,freight,fee,ads,cont=[D(r[k]) for k in ['List sales USD','Discount USD','Refund USD','Net revenue USD','Product cost USD','Freight USD','Fees USD','Advertising USD','Contribution USD']]
    assert g-disc-ref==n and n-c-freight-fee-ads==cont
    reasons=set(filter(None,r['Reasons'].split('; ')))
    actual=set()
    if disc/g>D('.3'):actual.add('Discount above 30 percent')
    if cont<0:actual.add('Negative contribution')
    if ref>0:actual.add('Refund recorded')
    if n>0 and freight/n>D('.2'):actual.add('Freight above 20 percent of net sales')
    assert reasons==actual
    assert all((r['Order ID'],a) in flagset for a in actual)
    assert bool(actual)==(r['Flagged']=='True')
    assert D(r['FX to USD'])>0
    assert abs(D(r['Local net revenue'])*D(r['FX to USD'])-n)<D('.02')
    net+=n;contribution+=cont;losses+=cont<0;flagged+=bool(actual)
    # With all costs and offsets fixed, baseline sensitivity must equal actual.
    assert g*(1+D(0))-disc-ref-c-freight-fee-ads==cont
assert net==D(str(expected['net_revenue_usd']))
assert contribution==D(str(expected['contribution_usd']))
assert flagged==expected['flagged_orders'] and losses==expected['loss_making_orders']
assert len({(r['Month key'],r['Region key'],r['Channel key'],r['Product key']) for r in budget})==len(budget)
assert {tuple(r[k] for k in ['Month key','Region key','Channel key','Product key']) for r in budget}=={tuple(r[k] for k in ['Month key','Region key','Channel key','Product key']) for r in orders}
assert Counter(r['Rule'] for r in flags)==expected['rule_counts']
print(json.dumps({'result':'passed','orders':len(orders),'budget_segments':len(budget),'net_revenue_usd':str(net),'contribution_usd':str(contribution),'flagged_orders':flagged,'loss_making_orders':losses,'checks':['grain','foreign keys','revenue identity','contribution identity','policy flags','currency conversion','scenario baseline','budget coverage','control totals']}))
