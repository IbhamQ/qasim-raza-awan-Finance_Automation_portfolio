from pathlib import Path
import calendar,csv,json,random,shutil,uuid,zipfile
from datetime import date,timedelta
from collections import defaultdict,Counter

ROOT=Path(__file__).resolve().parent
if not (ROOT/'Meridian_Revenue_Margin.pbip').exists():ROOT=ROOT/'meridian_margin'
REPORT=ROOT/'Meridian_Revenue_Margin.Report';MODEL=ROOT/'Meridian_Revenue_Margin.SemanticModel'
MODEL.mkdir(exist_ok=True);DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
BASE='https://developer.microsoft.com/json-schemas/fabric/'
BG='#F3F5F8';NAVY='#102437';INK='#183349';TEAL='#087F8C';MINT='#4FD1B5';MUTED='#62758A';ORANGE='#C97B38';RED='#BA4C57'
rng=random.Random(543)
def uid():return uuid.uuid4().hex[:20]
def write(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def csvwrite(name,headers,rows):
    with (DATA/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:w=csv.writer(f);w.writerow(headers);w.writerows(rows)
def money(cents):return round(cents/100,2)

# Deterministic synthetic commerce data. Source amounts are generated in cents.
products=[(1,'TRV-01','Cabin case','Travel',12900,.43),(2,'TRV-02','Checked case','Travel',19900,.47),(3,'TRV-03','Travel organiser','Travel',3900,.36),(4,'TRV-04','Weekender bag','Travel',8900,.41),
 (5,'FIT-01','Pilates mat','Fitness',6900,.46),(6,'FIT-02','Resistance set','Fitness',4900,.39),(7,'FIT-03','Home training kit','Fitness',15900,.51),(8,'FIT-04','Recovery roller','Fitness',5900,.42),
 (9,'HOM-01','Desk organiser','Home',7900,.39),(10,'HOM-02','Modular shelf','Home',14900,.53),(11,'HOM-03','Task light','Home',9900,.45),(12,'HOM-04','Storage set','Home',11900,.48)]
regions=[(1,'North America','USD',1.0),(2,'United Kingdom','GBP',1.27),(3,'Gulf','AED',.2723),(4,'Asia Pacific','USD',1.0)]
channels=[(1,'Direct web'),(2,'Marketplace'),(3,'Wholesale')]
months=[(y,m) for y in [2025,2026] for m in range(1,13) if (y,m)<=(2026,6)]
cal=[]
day=date(2025,1,1)
while day<=date(2026,6,30):
    cal.append([int(day.strftime('%Y%m%d')),day.isoformat(),day.year,day.year*100+day.month,day.strftime('%Y-%m'),day.strftime('%b %Y')]);day+=timedelta(days=1)
orders=[];flags=[];monthly=defaultdict(lambda:[0,0]); rulecounts=Counter()
for mi,(year,month) in enumerate(months):
    for n in range(400):
        oid=f'MRD-{year}{month:02}-{n+1:04}';prod=rng.choice(products);region=rng.choices(regions,[.42,.25,.18,.15])[0];channel=rng.choices(channels,[.50,.35,.15])[0]
        units=rng.choices([1,2,3,5],[.52,.29,.14,.05])[0];day=rng.randint(1,calendar.monthrange(year,month)[1]);key=year*10000+month*100+day
        gross=prod[4]*units;discount=rng.choice([0,.05,.10,.15,.20,.25])
        if channel[0]==3:discount+=.08
        if mi>=12 and channel[0]==2 and prod[3]=='Fitness':discount=.35
        discount=min(discount,.4);disc=round(gross*discount)
        refund=round((gross-disc)*rng.choice([.25,.5,1])) if rng.random()<.075 else 0
        net=gross-disc-refund;cogs=round(gross*prod[5]);freight=round(units*(rng.randint(450,1100)+(500 if region[0]==3 else 0)))
        fees=round(max(0,net)*{1:.029,2:.15,3:.005}[channel[0]])
        ads=round(max(0,net)*({1:.13,2:.055,3:0}[channel[0]]+rng.uniform(0,.045)))
        contrib=net-cogs-freight-fees-ads
        reasons=[]
        if discount>.30:reasons.append('Discount above 30 percent')
        if contrib<0:reasons.append('Negative contribution')
        if refund>0:reasons.append('Refund recorded')
        if net>0 and freight/net>.2:reasons.append('Freight above 20 percent of net sales')
        fx=round(region[3]*(1+rng.uniform(-.015,.015)),5) if region[2]!='USD' else 1
        # Local amount is illustrative; USD ledger amount is authoritative for all report measures.
        row=[oid,key,year*100+month,prod[0],region[0],channel[0],units,money(gross),money(disc),money(refund),money(net),money(cogs),money(freight),money(fees),money(ads),money(contrib),region[2],fx,round(money(net)/fx,2),bool(reasons),'; '.join(reasons),0,0]
        orders.append(row)
        for reason in reasons:flags.append([oid,reason]);rulecounts[reason]+=1
        monthly[(year*100+month,region[0],channel[0],prod[0])][0]+=net;monthly[(year*100+month,region[0],channel[0],prod[0])][1]+=contrib
budgets=[]
for (month,region,channel,product),(net,contribution) in sorted(monthly.items()):
    target=round(net*rng.uniform(.93,1.17));targetmargin=rng.uniform(.25,.34)
    budgets.append([month,region,channel,product,money(target),money(round(target*targetmargin))])
ordercols=[('Order ID','string'),('Date key','int64'),('Month key','int64'),('Product key','int64'),('Region key','int64'),('Channel key','int64'),('Units','int64'),('List sales USD','double'),('Discount USD','double'),('Refund USD','double'),('Net revenue USD','double'),('Product cost USD','double'),('Freight USD','double'),('Fees USD','double'),('Advertising USD','double'),('Contribution USD','double'),('Local currency','string'),('FX to USD','double'),('Local net revenue','double'),('Flagged','boolean'),('Reasons','string'),('Revenue control delta','double'),('Contribution control delta','double')]
for name,cols,rows in [('Orders',ordercols,orders),('Budget',[('Month key','int64'),('Region key','int64'),('Channel key','int64'),('Product key','int64'),('Budget revenue USD','double'),('Budget contribution USD','double')],budgets)]:csvwrite(name,[c[0] for c in cols],rows)
csvwrite('Flags',['Order ID','Rule'],flags)

def literal(v):
    if v is None:return 'null'
    if isinstance(v,bool):return 'true' if v else 'false'
    if isinstance(v,(int,float)):return str(v)
    return '"'+str(v).replace('#','#(#)').replace('"','""').replace('\n','#(lf)')+'"'
tables=[]
def table(name,cols,rows,hidden=False):
    # Keep M syntax small: embedded compressed JSON, then explicit column types.
    import base64, gzip
    raw=json.dumps(rows,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
    encoded=base64.b64encode(gzip.compress(raw,mtime=0)).decode('ascii')
    assert gzip.decompress(base64.b64decode(encoded))==raw
    chunks=',\n'.join('        "'+encoded[i:i+16000]+'"' for i in range(0,len(encoded),16000))
    names='{'+', '.join(literal(n) for n,t in cols)+'}'
    mtypes={'string':'type text','int64':'Int64.Type','double':'type number','boolean':'type logical','dateTime':'type date'}
    transforms='{'+', '.join('{'+literal(n)+', '+mtypes[t]+'}' for n,t in cols)+'}'
    expression=['Table.TransformColumnTypes(', '    Table.FromRows(',
        '        Json.Document(Binary.Decompress(Binary.FromText(Text.Combine({',chunks,
        '        }), BinaryEncoding.Base64), Compression.GZip)),',
        '        '+names+'),', '    '+transforms+', "en-US")']
    columns=[]
    for n,t in cols:
        c={'name':n,'dataType':t,'sourceColumn':n,'summarizeBy':'none'}
        if t=='double':c['formatString']='$#,0.00;($#,0.00);$0.00' if 'USD' in n else '0.00'
        if t=='int64':c['formatString']='#,0'
        if t=='dateTime':c.update(formatString='dd mmm yyyy',annotations=[{'name':'UnderlyingDateTimeDataType','value':'Date'}])
        if n.endswith(' key'):c['isHidden']=True
        columns.append(c)
    t={'name':name,'columns':columns,'partitions':[{'name':name,'mode':'import','source':{'type':'m','expression':expression}}]}
    if hidden:t['isHidden']=True
    tables.append(t);return t
fact=table('Orders',ordercols,orders)
dates=table('Calendar',[('Date key','int64'),('Date','dateTime'),('Year','int64'),('Month key','int64'),('Year month','string'),('Month','string')],cal)
dates['dataCategory']='Time'
for c in dates['columns']:
    if c['name'] in ['Year month','Month']:c['sortByColumn']='Month key'
    if c['name']=='Date':c['isKey']=True
table('Products',[('Product key','int64'),('SKU','string'),('Product','string'),('Category','string')],[list(p[:4]) for p in products])
table('Regions',[('Region key','int64'),('Region','string')],[[r[0],r[1]] for r in regions])
table('Channels',[('Channel key','int64'),('Channel','string')],channels)
table('Budget',[('Month key','int64'),('Region key','int64'),('Channel key','int64'),('Product key','int64'),('Budget revenue USD','double'),('Budget contribution USD','double')],budgets)
table('Flags',[('Order ID','string'),('Rule','string')],flags)
bridge=table('Bridge',[('Step','string'),('Sequence','int64')],[[s,i] for i,s in enumerate(['List sales','Discounts','Refunds','Product cost','Freight','Platform fees','Advertising'],1)])
bridge['columns'][0]['sortByColumn']='Sequence'
for name in ['Scenario','Scenario axis']:
    t=table(name,[('Price change','double'),('Scenario','string')],[[v,f'{v:+.0%}' if v else 'Baseline'] for v in [-.10,-.05,0,.025,.05,.075,.10]])
    t['columns'][0]['formatString']='0.0%';t['columns'][1]['sortByColumn']='Price change'

measures=[]
def dax(name,exp,fmt='$#,0;($#,0);$0',folder='Commercial',desc=''):
    measures.append({'name':name,'expression':exp,'formatString':fmt,'displayFolder':folder,'description':desc})
dax('Orders','COUNTROWS(Orders)','#,0');dax('Total units','SUM(Orders[Units])','#,0')
for name,col in [('List sales','List sales USD'),('Discounts','Discount USD'),('Refunds','Refund USD'),('Net revenue','Net revenue USD'),('Product cost','Product cost USD'),('Freight','Freight USD'),('Platform fees','Fees USD'),('Advertising','Advertising USD'),('Contribution','Contribution USD')]:dax(name,f'SUM(Orders[{col}])')
dax('Contribution margin','DIVIDE([Contribution], [Net revenue])','0.0%')
dax('Discount rate','DIVIDE([Discounts], [List sales])','0.0%');dax('Refund rate','DIVIDE([Refunds], [List sales] - [Discounts])','0.0%')
dax('Average order value','DIVIDE([Net revenue], [Orders])','$#,0.00')
dax('Contribution per order','DIVIDE([Contribution], [Orders])','$#,0.00')
dax('Budget revenue','CALCULATE(SUM(Budget[Budget revenue USD]), TREATAS(VALUES(Calendar[Month key]), Budget[Month key]))')
dax('Budget contribution','CALCULATE(SUM(Budget[Budget contribution USD]), TREATAS(VALUES(Calendar[Month key]), Budget[Month key]))')
dax('Revenue versus budget','[Net revenue] - [Budget revenue]')
dax('Revenue versus budget percent','DIVIDE([Revenue versus budget], [Budget revenue])','+0.0%;-0.0%;0.0%')
dax('Contribution versus budget','[Contribution] - [Budget contribution]')
dax('Budget margin','DIVIDE([Budget contribution], [Budget revenue])','0.0%')
dax('Margin gap bps','([Contribution margin] - [Budget margin]) * 10000','+0 "bps";-0 "bps";0 "bps"')
dax('Prior month revenue','CALCULATE([Net revenue], DATEADD(Calendar[Date], -1, MONTH))')
dax('Revenue month on month','DIVIDE([Net revenue] - [Prior month revenue], [Prior month revenue])','+0.0%;-0.0%;0.0%')
dax('Prior year revenue','CALCULATE([Net revenue], SAMEPERIODLASTYEAR(Calendar[Date]))')
dax('Revenue year on year','DIVIDE([Net revenue] - [Prior year revenue], [Prior year revenue])','+0.0%;-0.0%;0.0%')
dax('Flagged orders','COALESCE(CALCULATE([Orders], KEEPFILTERS(Orders[Flagged] = TRUE())), 0)','#,0','Controls')
dax('Flag rate','DIVIDE([Flagged orders], [Orders])','0.0%','Controls')
dax('Commercial flags','COUNTROWS(Flags)','#,0','Controls')
dax('Loss making orders','COALESCE(CALCULATE([Orders], KEEPFILTERS(Orders[Contribution USD] < 0)), 0)','#,0','Controls')
dax('Loss on negative orders','-SUMX(FILTER(Orders, Orders[Contribution USD] < 0), Orders[Contribution USD])',folder='Controls')
dax('Revenue identity errors','COALESCE(COUNTROWS(FILTER(Orders, ABS(Orders[Net revenue USD] - Orders[List sales USD] + Orders[Discount USD] + Orders[Refund USD]) > 0.01)), 0)','#,0','Controls')
dax('Contribution identity errors','COALESCE(COUNTROWS(FILTER(Orders, ABS(Orders[Contribution USD] - Orders[Net revenue USD] + Orders[Product cost USD] + Orders[Freight USD] + Orders[Fees USD] + Orders[Advertising USD]) > 0.01)), 0)','#,0','Controls')
dax('Duplicate order IDs','[Orders] - DISTINCTCOUNT(Orders[Order ID])','#,0','Controls')
dax('Bridge amount','SWITCH(SELECTEDVALUE(Bridge[Step]), "List sales", [List sales], "Discounts", -[Discounts], "Refunds", -[Refunds], "Product cost", -[Product cost], "Freight", -[Freight], "Platform fees", -[Platform fees], "Advertising", -[Advertising])',folder='Margin bridge')
dax('Selected price change','SELECTEDVALUE(Scenario[Price change], 0)','+0.0%;-0.0%;0.0%','Scenario')
dax('Scenario revenue','[List sales] * (1 + [Selected price change]) - [Discounts] - [Refunds]',folder='Scenario')
dax('Scenario contribution','[Scenario revenue] - [Product cost] - [Freight] - [Platform fees] - [Advertising]',folder='Scenario')
dax('Scenario margin','DIVIDE([Scenario contribution], [Scenario revenue])','0.0%','Scenario')
dax('Scenario contribution change','[Scenario contribution] - [Contribution]',folder='Scenario')
dax('Scenario curve margin','VAR Shift = SELECTEDVALUE(\'Scenario axis\'[Price change], 0) VAR Revenue = [List sales] * (1 + Shift) - [Discounts] - [Refunds] RETURN DIVIDE(Revenue - [Product cost] - [Freight] - [Platform fees] - [Advertising], Revenue)','0.0%','Scenario')
dax('Revenue share','DIVIDE([Net revenue], CALCULATE([Net revenue], ALLSELECTED(Products)))','0.0%')
dax('Contribution rank','RANKX(ALLSELECTED(Products[Product]), [Contribution], , DESC, DENSE)','0')
fact['measures']=measures
rels=[]
def rel(ft,fc,tt,tc):rels.append(dict(name=str(uuid.uuid4()),fromTable=ft,fromColumn=fc,toTable=tt,toColumn=tc,fromCardinality='many',toCardinality='one',crossFilteringBehavior='oneDirection'))
for ft,fc,tt,tc in [('Orders','Date key','Calendar','Date key'),('Orders','Product key','Products','Product key'),('Orders','Region key','Regions','Region key'),('Orders','Channel key','Channels','Channel key'),('Budget','Region key','Regions','Region key'),('Budget','Channel key','Channels','Channel key'),('Budget','Product key','Products','Product key'),('Flags','Order ID','Orders','Order ID')]:rel(ft,fc,tt,tc)
write(MODEL/'definition.pbism',{'$schema':BASE+'item/semanticModel/definitionProperties/1.0.0/schema.json','version':'4.0','settings':{}})
write(MODEL/'.platform',{'$schema':BASE+'gitIntegration/platformProperties/2.0.0/schema.json','metadata':{'type':'SemanticModel','displayName':'Meridian Revenue and Margin'},'config':{'version':'2.0','logicalId':str(uuid.uuid4())}})
write(MODEL/'model.bim',{'name':'Meridian_Revenue_Margin','compatibilityLevel':1601,'model':{'culture':'en-US','defaultPowerBIDataSourceVersion':'powerBI_V3','sourceQueryCulture':'en-US','tables':tables,'relationships':rels,'annotations':[{'name':'PBI_ProTooling','value':'["DevMode"]'}]}})

def lit(v):return {'expr':{'Literal':{'Value':('true' if v else 'false') if isinstance(v,bool) else str(v)+'D' if isinstance(v,(int,float)) else "'"+v.replace("'","''")+"'"}}}
def fill(c):return {'solid':{'color':lit(c)}}
def prop(**p):return [{'properties':p}]
def field(t,n,m=False):return {'field':{'Measure' if m else 'Column':{'Expression':{'SourceRef':{'Entity':t}},'Property':n}},'queryRef':t+'.'+n,'nativeQueryRef':n}
def c(t,n):return field(t,n)
def m(n):return field('Orders',n,True)
PAGES=REPORT/'definition/pages'
for x in PAGES.iterdir():
    if x.is_dir():shutil.rmtree(x)
names=['Executive','Margin bridge','Price lab','Channel mix','Exception queue','Model and controls'];ids=[uid() for _ in names];visuals=[]
for pid,name in zip(ids,names):write(PAGES/pid/'page.json',{'$schema':BASE+'item/report/definition/page/2.1.0/schema.json','name':pid,'displayName':name,'displayOption':'FitToPage','width':1600,'height':1000,'objects':{'background':prop(color=fill(BG),transparency=lit(0))}})
def v(pid,typ,x,y,w,h,title=None,query=None,objects=None,bg='#FFFFFF',layer=10):
    vid=uid();q={'visualType':typ,'visualContainerObjects':{'background':prop(show=lit(True),color=fill(bg),transparency=lit(0)),'border':prop(show=lit(False)),'padding':prop(left=lit(14),right=lit(14),top=lit(12),bottom=lit(12)),'title':prop(show=lit(bool(title)),**({'text':lit(title),'fontColor':fill(INK),'fontFamily':lit('Segoe UI Semibold'),'fontSize':lit(12)} if title else {}))}}
    if query:q['query']={'queryState':{role:{'projections':vals} for role,vals in query.items()}}
    if objects:q['objects']=objects
    obj={'$schema':BASE+'item/report/definition/visualContainer/2.9.0/schema.json','name':vid,'position':{'x':x,'y':y,'width':w,'height':h,'z':layer,'tabOrder':len(visuals)},'visual':q}
    write(PAGES/pid/'visuals'/vid/'visual.json',obj);visuals.append((pid,obj));return obj
def revise(pid,obj):write(PAGES/pid/'visuals'/obj['name']/'visual.json',obj)
def text(pid,x,y,w,h,body,size=13,color=MUTED,bg=BG,bold=False,layer=20):
    paragraphs=[{'textRuns':[{'value':line,'textStyle':{'fontFamily':'Segoe UI Semibold' if bold else 'Segoe UI','fontSize':str(size)+'px','color':color}}]} for line in body.split('\n')]
    obj=v(pid,'textbox',x,y,w,h,objects={'general':prop(paragraphs=paragraphs)},bg=bg,layer=layer)
    obj['visual']['visualContainerObjects']['padding']=prop(left=lit(0),right=lit(0),top=lit(0),bottom=lit(0));revise(pid,obj);return obj
def button(pid,index,target,label):
    active=pid==target;bg=TEAL if active else '#193449'
    obj=v(pid,'actionButton',20,232+index*61,184,49,objects={
      'text':[{'properties':{'show':lit(True)}},{'properties':{'text':lit(label),'fontSize':lit(11),'fontColor':fill('#FFFFFF'),'horizontalAlignment':lit('left'),'verticalAlignment':lit('middle'),'leftMargin':lit(14)},'selector':{'id':'default'}}],
      'fill':[{'properties':{'show':lit(True)}},{'properties':{'fillColor':fill(bg)},'selector':{'id':'default'}}],
      'outline':prop(show=lit(False)),'icon':prop(show=lit(False)),
      'shape':[{'properties':{'tileShape':lit('rectangle')}},{'properties':{'tileShape':lit('rectangle')},'selector':{'id':'default'}}]},bg=NAVY)
    obj['visual']['visualContainerObjects']['background']=prop(show=lit(False))
    obj['visual']['visualContainerObjects']['visualLink']=prop(show=lit(True),type=lit('PageNavigation'),navigationSection=lit(target),tooltip=lit('Open '+label))
    revise(pid,obj)
def shell(pid,n,title,subtitle):
    text(pid,0,0,224,1000,'',bg=NAVY,layer=0)
    text(pid,22,30,180,38,'MERIDIAN',22,'#FFFFFF',NAVY,True)
    text(pid,22,76,180,62,'REVENUE AND\nMARGIN INTELLIGENCE',11,MINT,NAVY,True)
    text(pid,22,174,180,30,'EXPLORE THE MODEL',10,'#97ACBD',NAVY,True)
    for i,(target,label) in enumerate(zip(ids,names)):button(pid,i,target,label)
    text(pid,22,740,180,140,'18 MONTHS\n7,200 ORDERS\n12 PRODUCTS\n4 REGIONS',12,'#C4D4E0',NAVY)
    text(pid,22,922,180,58,'QASIM RAZA AWAN\nSYNTHETIC PORTFOLIO CASE',10,MINT,NAVY,True)
    text(pid,256,28,1308,25,f'COMMERCIAL ANALYTICS   /   {n:02}   /   USD REPORTING',11,TEAL,bold=True)
    text(pid,256,65,1308,49,title,30,INK,bold=True)
    text(pid,256,120,1308,39,subtitle,14)
    text(pid,256,965,1308,24,'Demonstration data · Jan 2025–Jun 2026 · Budget and FX assumptions are synthetic · Prepared with AI-assisted implementation',10)
def slicers(pid,scenario=False):
    specs=[(256,'Calendar','Year month',290),(562,'Regions','Region',290),(868,'Channels','Channel',290),(1174,'Scenario' if scenario else 'Products','Scenario' if scenario else 'Category',390)]
    for x,t,col,w in specs:
        obj=v(pid,'slicer',x,176,w,82,query={'Values':[c(t,col)]},objects={'data':prop(mode=lit('Dropdown')),'header':prop(show=lit(True),text=lit(col),fontColor=fill(INK))})
def card(pid,x,y,w,name,accent=INK):
    return v(pid,'card',x,y,w,112,query={'Values':[m(name)]},objects={'labels':prop(fontSize=lit(27),color=fill(accent),labelDisplayUnits=lit(0),labelPrecision=lit(1)),'categoryLabels':prop(show=lit(True),fontSize=lit(10),color=fill(MUTED))})
def chart(pid,typ,x,y,w,h,title,query):
    obj=v(pid,typ,x,y,w,h,title,query)
    if 'Category' in query:obj['visual']['query']['sortDefinition']={'sort':[{'field':query['Category'][0]['field'],'direction':'Ascending'}],'isDefaultSort':False}
    revise(pid,obj);return obj
def grid(pid,x,y,w,h,title,fields):
    return v(pid,'tableEx',x,y,w,h,title,{'Values':fields},objects={'columnHeaders':prop(autoSizeColumnWidth=lit(True),columnAdjustment=lit('growToFit'),fontSize=lit(10),fontColor=fill('#FFFFFF'),backColor=fill(NAVY),wordWrap=lit(True)),'values':prop(fontSize=lit(10),fontColorPrimary=fill(INK),fontColorSecondary=fill(INK),backColorPrimary=fill('#FFFFFF'),backColorSecondary=fill('#EDF3F7'),wordWrap=lit(True)),'total':prop(totals=lit(False))})

p=ids[0];shell(p,1,'Growth is only useful when margin follows.','A consolidated view of net revenue, contribution and plan performance. Use the filters to investigate the mix.');slicers(p)
for i,name in enumerate(['Net revenue','Contribution','Contribution margin','Revenue versus budget percent','Orders','Average order value']):card(p,256+i*220,278,208,name,TEAL if i in [1,2] else INK)
chart(p,'lineChart',256,410,846,312,'Net revenue against plan',{'Category':[c('Calendar','Year month')],'Y':[m('Net revenue'),m('Budget revenue')]})
chart(p,'clusteredBarChart',1122,410,442,312,'Contribution by channel',{'Category':[c('Channels','Channel')],'Y':[m('Contribution')]})
grid(p,256,742,846,200,'Category performance',[c('Products','Category'),m('Net revenue'),m('Revenue share'),m('Contribution'),m('Contribution margin')])
text(p,1142,768,400,150,'ANALYST VIEW\nStart with margin, then use channel and category filters. Revenue share is calculated within the selected product set; it changes with the filters.',14,bg='#FFFFFF')

p=ids[1];shell(p,2,'Follow every dollar from list price to contribution.','A transparent margin bridge and a product scorecard separate commercial leakage from fulfilment cost.');slicers(p)
for i,name in enumerate(['List sales','Discounts','Refunds','Product cost','Freight','Contribution']):card(p,256+i*220,278,208,name,ORANGE if i in [1,2,4] else INK)
obj=chart(p,'waterfallChart',256,410,1308,302,'Margin bridge · reporting USD',{'Category':[c('Bridge','Step')],'Y':[m('Bridge amount')]})
obj['visual']['objects']={'sentimentColors':prop(increaseFill=fill(TEAL),decreaseFill=fill(ORANGE),totalFill=fill(INK))};revise(p,obj)
grid(p,256,732,1308,210,'Product economics',[c('Products','SKU'),c('Products','Product'),m('Net revenue'),m('Discount rate'),m('Refund rate'),m('Freight'),m('Platform fees'),m('Contribution margin'),m('Contribution per order')])

p=ids[2];shell(p,3,'Test a price change before making a pricing decision.','An explicit sensitivity model. Volume, absolute discounts, refunds and all costs remain fixed; demand elasticity is not modelled.');slicers(p,True)
for i,name in enumerate(['Selected price change','Scenario revenue','Scenario contribution','Scenario margin','Scenario contribution change']):card(p,256+i*266,278,244,name,TEAL if i in [2,3,4] else INK)
chart(p,'lineChart',256,410,704,320,'Contribution margin across price scenarios',{'Category':[c('Scenario axis','Scenario')],'Y':[m('Scenario curve margin'),m('Contribution margin')]})
chart(p,'scatterChart',980,410,584,320,'Discount versus margin · one bubble per product',{'Category':[c('Products','Product')],'X':[m('Discount rate')],'Y':[m('Contribution margin')],'Size':[m('List sales')],'Series':[c('Products','Category')]})
grid(p,256,750,704,192,'Selected scenario by category',[c('Products','Category'),m('Contribution'),m('Scenario contribution'),m('Scenario contribution change')])
text(p,1000,775,540,140,'SCENARIO DISCIPLINE\nThis is a sensitivity, not a forecast. A 5% price change applies to list sales. The commercial cost of lost volume or higher refunds is outside this model.',14,bg='#FFFFFF')

p=ids[3];shell(p,4,'Which markets and channels earn their growth?','Compare volume and contribution together. A larger revenue share does not necessarily mean a stronger unit economy.');slicers(p)
for i,name in enumerate(['Total units','Contribution per order','Discount rate','Refund rate','Margin gap bps']):card(p,256+i*266,278,244,name,TEAL if i in [1] else INK)
chart(p,'clusteredColumnChart',256,410,704,300,'Regional contribution against plan',{'Category':[c('Regions','Region')],'Y':[m('Contribution'),m('Budget contribution')]})
chart(p,'lineChart',980,410,584,300,'Contribution margin by channel over time',{'Category':[c('Calendar','Year month')],'Y':[m('Contribution margin')],'Series':[c('Channels','Channel')]})
grid(p,256,730,1308,212,'Market and channel scorecard',[c('Regions','Region'),c('Channels','Channel'),m('Orders'),m('Net revenue'),m('Budget revenue'),m('Revenue versus budget percent'),m('Contribution margin'),m('Budget margin')])

p=ids[4];shell(p,5,'Turn commercial exceptions into a review queue.','Flags identify policy thresholds and margin risks. They are review signals, not evidence of an accounting error.');slicers(p)
for i,name in enumerate(['Flagged orders','Flag rate','Loss making orders','Loss on negative orders','Commercial flags']):card(p,256+i*266,278,244,name,ORANGE if i!=1 else INK)
chart(p,'clusteredBarChart',256,410,520,292,'Commercial risk signals · overlapping flags',{'Category':[c('Flags','Rule')],'Y':[m('Commercial flags')]})
grid(p,796,410,768,292,'Risk distribution',[c('Products','Category'),c('Channels','Channel'),m('Flagged orders'),m('Loss making orders'),m('Loss on negative orders')])
obj=grid(p,256,722,1308,220,'Order exception register · flagged orders only',[c('Orders','Order ID'),c('Products','SKU'),c('Regions','Region'),c('Channels','Channel'),c('Orders','Net revenue USD'),c('Orders','Contribution USD'),c('Orders','Reasons')])
flag_condition={'In':{'Expressions':[{'Column':{'Expression':{'SourceRef':{'Source':'o'}},'Property':'Flagged'}}],'Values':[[{'Literal':{'Value':'true'}}]]}}
obj['filterConfig']={'filters':[{'name':uid(),'field':c('Orders','Flagged')['field'],'type':'Categorical','howCreated':'User','filter':{'Version':2,'From':[{'Name':'o','Entity':'Orders','Type':0}],'Where':[{'Condition':flag_condition}]}}]};revise(p,obj)

p=ids[5];shell(p,6,'A clear model makes the analysis defensible.','Source files, relationships, calculation definitions and independent control checks are included with the project.');slicers(p)
for i,name in enumerate(['Orders','Duplicate order IDs','Revenue identity errors','Contribution identity errors']):card(p,256+i*334,278,306,name,TEAL)
text(p,278,435,600,213,'MODEL AND GRAIN\nOrders: one row per order. Calendar, Products, Regions and Channels filter Orders. Products, Regions and Channels also filter Budget. Flags inherit order context.\nMonthly budgets use TREATAS against selected calendar months, avoiding a misleading first-day-only budget relationship.',16,bg='#FFFFFF')
text(p,936,435,600,213,'DEFINITIONS\nNet revenue = list sales − discounts − refunds.\nContribution = net revenue − product cost − freight − fees − advertising.\nContribution excludes corporate overhead, tax and financing. It is not net profit.',16,bg='#FFFFFF')
text(p,278,694,600,225,'VALIDATION AND LINEAGE\nSeeded generator → raw USD order ledger → independent CSV checks → portable Power Query tables → semantic model → DAX and report visuals.\nSynthetic budgets and exchange rates support the example. All monetary analysis uses the authoritative USD ledger amounts.',15,bg='#FFFFFF')
text(p,936,694,600,225,'WHAT THIS CASE DEMONSTRATES\nCommercial analytics, multi-table modelling, DAX, monthly plan comparisons, scenario modelling and exception reporting.\nThis is an AI-assisted portfolio demonstration using synthetic records. It is not a client deployment, a live Fabric connection or evidence of forecast accuracy.',15,bg='#FFFFFF')

write(PAGES/'pages.json',{'$schema':BASE+'item/report/definition/pagesMetadata/1.1.0/schema.json','pageOrder':ids,'activePageName':ids[0]})
theme={'name':'MeridianTheme.json','dataColors':[TEAL,ORANGE,'#5A7BA6','#8E72AD','#6FA38F'],'background':'#FFFFFF','foreground':INK,'tableAccent':TEAL,'textClasses':{'label':{'fontFace':'Segoe UI','fontSize':11,'color':INK},'title':{'fontFace':'Segoe UI Semibold','fontSize':13,'color':INK}}}
write(REPORT/'StaticResources/RegisteredResources/MeridianTheme.json',theme)
report=json.loads((REPORT/'definition/report.json').read_text());report['themeCollection']['customTheme']={'name':'MeridianTheme.json','reportVersionAtImport':{'visual':'2.9.0','report':'3.3.0','page':'2.1.0'},'type':'RegisteredResources'}
report['resourcePackages']=[x for x in report['resourcePackages'] if x['type']!='RegisteredResources'];report['resourcePackages'].append({'name':'RegisteredResources','type':'RegisteredResources','items':[{'name':'MeridianTheme.json','path':'MeridianTheme.json','type':'CustomTheme'}]});write(REPORT/'definition/report.json',report)
(ROOT/'Measures.dax').write_text('\n\n'.join(x['name']+' =\n'+x['expression'] for x in measures))
# Structural checks are separate from native Power BI runtime verification.
inventory={t['name']:{x['name'] for x in t['columns']}|{x['name'] for x in t.get('measures',[])} for t in tables}
for t in tables:
    column_names={x['name'].casefold() for x in t['columns']}
    measure_names=[x['name'].casefold() for x in t.get('measures',[])]
    assert not column_names.intersection(measure_names), f"Column/measure name collision in {t['name']}"
    assert len(measure_names)==len(set(measure_names)), f"Duplicate measure name in {t['name']}"
for pid,obj in visuals:
    z=obj['position'];assert z['x']>=0 and z['y']>=0 and z['x']+z['width']<=1600 and z['y']+z['height']<=1000
    for role in obj['visual'].get('query',{}).get('queryState',{}).values():
        for f in role['projections']:
            q=next(iter(f['field'].values()));assert q['Property'] in inventory[q['Expression']['SourceRef']['Entity']]
summary={'orders':len(orders),'months':len(months),'products':len(products),'regions':len(regions),'channels':len(channels),'tables':len(tables),'relationships':len(rels),'measures':len(measures),'pages':len(names),'visuals':len(visuals),'net_revenue_usd':round(sum(r[10] for r in orders),2),'contribution_usd':round(sum(r[15] for r in orders),2),'flagged_orders':sum(r[19] for r in orders),'flags':len(flags),'loss_making_orders':sum(r[15]<0 for r in orders),'rule_counts':dict(rulecounts)}
write(ROOT/'expected_results.json',summary);print(json.dumps(summary))
