# Meridian Revenue and Margin Intelligence

A native Power BI portfolio case study prepared for Qasim Raza Awan with AI-assisted implementation. Meridian is a fictional consumer-products business. All transactions, budgets and currency rates are synthetic.

## Revision 4

User screenshots confirm all six pages render with populated data in Power BI Desktop, including matching headline totals. Two identity-error measures now return zero instead of BLANK when no violations exist. Filter/scenario interactions have not yet been separately verified.

## Revision 3

Replaces the large row-by-row M expressions with compressed embedded JSON and explicit column types. This reduces query parsing work without external paths or credentials. It is a mitigation for the reported stalled refresh; Desktop runtime verification is still required. Close the stuck Desktop session and extract into a new folder before opening.

## Revision 2

Corrects the Power BI Desktop load failure caused by the Units column and measure sharing a name. The measure is now Total units, with its report binding updated. The generator now checks for column/measure name collisions. Extract this revision into a fresh folder.

## Open the report

1. Extract the entire ZIP into a new local folder.
2. Open **Meridian_Revenue_Margin.pbip**. Keep its Report and SemanticModel folders together.
3. Click **Home → Refresh** to populate the embedded sample data. No cloud account, gateway or external file path is needed.
4. Explore the six page tabs, or **Ctrl + click** the navigation buttons in Desktop editing mode. Published reading mode uses a normal click.
5. Save as a **Power BI report (.pbix)** after a successful refresh if you prefer a single file.

Use a current Power BI Desktop release. If prompted, enable the Power BI Project and enhanced report-format preview features, restart Desktop and reopen.

## Six analytical pages

| Page | Question answered |
| --- | --- |
| Executive | How are revenue, contribution and margin tracking against plan? |
| Margin bridge | Where do discounts, refunds and variable costs absorb list sales? |
| Price lab | What happens to contribution under an explicitly constrained price sensitivity? |
| Channel mix | Which regions, products and channels earn their growth? |
| Exception queue | Which orders breach commercial review thresholds or lose money? |
| Model and controls | Can each definition, control total and modelling choice be explained? |

The model contains 7,200 orders across 18 months, 12 products, four regions and three channels. Ten tables, eight relationships and 44 DAX measures support the report. Native visuals include cards, line/column charts, a waterfall margin bridge, a product-level scatter chart, an exception register, slicers and page-navigation buttons.

## Expected unfiltered values

- Orders: **7,200**.
- Net revenue: **USD 1,070,849.22**.
- Contribution: **USD 173,198.92**.
- Contribution margin: approximately **16.17%**.
- Flagged orders: **1,855**; individual, overlapping flags: **3,008**.
- Loss-making orders: **888**.
- Duplicate order IDs, revenue identity errors and contribution identity errors: **0** each.

## Definitions and modelling decisions

Net revenue is list sales less discounts and refunds. Contribution deducts product cost, freight, platform fees and advertising. It excludes corporate overhead, financing and tax; do not describe it as net profit. Refunded orders retain their recorded fulfilment/product costs in this demonstration; recovered inventory is not modelled.

All commercial measures use the authoritative USD ledger amounts. Local amounts and assumed transaction exchange rates are available for inspection. They are synthetic assumptions, not market-rate data.

The Calendar, Products, Regions and Channels dimensions filter order facts. Products, Regions and Channels also filter product-level monthly budgets. Budget measures use the selected calendar month keys through TREATAS, so monthly targets do not depend on selecting the first day of a month. There is no direct fact-to-fact relationship. Commercial flags inherit order context through the unique Order ID relationship.

Revenue share is relative to the selected product set. Monthly budget records are synthetic segment targets constructed for demonstration, not independent forecasts or evidence of predictive accuracy. Prior-period measures are included in the model for extension.

Commercial review flags are discounts above 30 percent of list sales, negative contribution, any refund, and freight above 20 percent of positive net revenue. These overlap and are not counts of accounting errors. The order register is filtered to flagged orders; it can contain negative-contribution and refund examples. Review thresholds are demonstration rules, not recommendations for a particular business.

## Price lab assumptions

Choose one price scenario. Baseline applies when no single scenario is selected. A price shift applies to list sales; units, absolute discounts, refunds, product cost, freight, fees and advertising remain fixed. The scenario curve uses a separate disconnected axis table so choosing a scenario does not collapse the curve to a single point.

This is a mechanical sensitivity, not a demand or elasticity model. It does not forecast lost sales, changes in fees, promotional response or refund rates. Its purpose is to make the assumed mechanism and limits inspectable.

## Reproduce and inspect

- `data/Orders.csv`, `Budget.csv` and `Flags.csv` are the exported synthetic source records.
- `Measures.dax` contains the readable DAX definitions.
- Run `python verify_data.py` for independent source-ledger checks covering keys, relationships, identities, flags, FX reconciliation, scenario baseline and budget coverage.
- `expected_results.json` records the control totals.
- Run `python build_report.py` to regenerate the source data, semantic model and visuals. Close Desktop first. Reopen and refresh after rebuilding.

## Verification status

The report definition is checked with Microsoft's Power BI report validator. Data, model bindings, visual positions and independent CSV control checks are checked during generation. Native rendering, DAX execution, slicer interactions, navigation, waterfall behaviour and refresh still need verification in Power BI Desktop. This is not a claim of a deployed Fabric pipeline or completed client project.

Professional portfolio: https://qasimawan-finnovative-automations.vercel.app/
