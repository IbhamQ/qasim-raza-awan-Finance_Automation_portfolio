"""Reproducible synthetic data-quality demonstration. Python 3.10+, standard library.
Run: python validate.py --demo; or --source source.csv --target target.csv.
Never aggregates duplicate keys. Match grain: reference + currency.
"""
import argparse, csv, json, re
from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).parent
FIELDS = ['reference', 'currency', 'amount', 'date', 'region']

def demo():
    source = []
    for i in range(1, 121):
        source.append(dict(zip(FIELDS, [f'ORD-{i:04}', 'EUR' if i % 4 == 0 else 'USD',
            f'{Decimal(100 + i * 7) + Decimal(i % 10)/100:.2f}',
            f'2026-{8 + (i-1)//40:02}-{1+(i-1)%28:02}', ['East','Central','West'][i%3]])))
    target = [dict(r) for r in source[:-6]]
    target[9]['amount'] = '182.10'
    target[24]['amount'] = '999.00'
    target[39]['date'] = '2026-13-01'
    source[49]['amount'] = 'not-a-number'
    target[59]['region'] = 'Unknown'
    target[69]['currency'] = 'GBP'
    target.append(dict(target[19]))
    source.append(dict(source[29]))
    target.append(dict(zip(FIELDS, ['ORD-9999','USD','825.00','2026-10-20','East'])))
    source.append(dict(zip(FIELDS, ['', 'USD', '100.00', '2026-10-20', 'West'])))
    for name, rows in [('source.csv', source), ('target.csv', target)]:
        write_csv(ROOT/name, rows, FIELDS)

def write_csv(path, rows, fields):
    with Path(path).open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)

def read(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        reader=csv.DictReader(f)
        if not set(FIELDS).issubset(reader.fieldnames or []):
            raise ValueError(f'{path}: required columns are {FIELDS}')
        return [dict(r, row_number=i) for i, r in enumerate(reader,2)]

def money(value):
    try:
        if not re.fullmatch(r'-?\d+(\.\d{1,2})?', str(value).strip()): return None
        result=Decimal(str(value).strip())
        return result if result.is_finite() else None
    except InvalidOperation: return None

def validate(source, target, tolerance=Decimal('0.01')):
    if tolerance < 0 or not tolerance.is_finite(): raise ValueError('Tolerance must be finite and nonnegative')
    groups=defaultdict(lambda: [[], []]); quarantined=[]
    for side, rows in enumerate([source,target]):
        for r in rows:
            ref=r['reference'].strip().upper(); currency=r['currency'].strip().upper()
            if not ref or not currency:
                quarantined.append(dict(side=['Source','Target'][side], **r)); continue
            groups[(ref,currency)][side].append(r)
    result=[]
    for (ref,currency),(a,b) in sorted(groups.items()):
        reasons=[]
        if len(a)>1 or len(b)>1: reasons.append('Duplicate key')
        if not a: reasons.append('Target only')
        if not b: reasons.append('Source only')
        if currency not in ['USD','EUR']: reasons.append('Unsupported currency')
        for label, rows in [('Source',a),('Target',b)]:
            for r in rows:
                if money(r['amount']) is None: reasons.append(f'{label}: invalid amount')
                try: date.fromisoformat(r['date'])
                except (ValueError,TypeError): reasons.append(f'{label}: invalid date')
                if r['region'] not in ['East','Central','West']: reasons.append(f'{label}: invalid region')
        sa=money(a[0]['amount']) if len(a)==1 else None
        ta=money(b[0]['amount']) if len(b)==1 else None
        variance=sa-ta if sa is not None and ta is not None else None
        if len(a)==1 and len(b)==1:
            if variance is not None and abs(variance)>tolerance: reasons.append('Amount mismatch')
            if a[0]['date']!=b[0]['date']: reasons.append('Date mismatch')
            if a[0]['region']!=b[0]['region']: reasons.append('Region mismatch')
        row=(a or b)[0]; reasons=sorted(set(reasons))
        result.append(dict(reference=ref,currency=currency,region=row['region'],
            period=row['date'][:7],source_count=len(a),target_count=len(b),
            source_amount=float(sa) if sa is not None else None,
            target_amount=float(ta) if ta is not None else None,
            variance=float(variance) if variance is not None else None,
            status='Review' if reasons else 'Matched', reasons='; '.join(reasons),
            source_rows=[r['row_number'] for r in a],target_rows=[r['row_number'] for r in b]))
    return dict(records=result,quarantine=quarantined,
        meta=dict(as_of='2026-11-15', data_type='Synthetic demonstration',
            source_rows=len(source),target_rows=len(target),tolerance=str(tolerance),
            distinct_keys=len(result),matched=sum(r['status']=='Matched' for r in result),
            review=sum(r['status']=='Review' for r in result),quarantined_rows=len(quarantined)))

def main():
    p=argparse.ArgumentParser();p.add_argument('--demo',action='store_true')
    p.add_argument('--source',default=str(ROOT/'source.csv'));p.add_argument('--target',default=str(ROOT/'target.csv'))
    p.add_argument('--tolerance',default='0.01');args=p.parse_args()
    if args.demo: demo()
    result=validate(read(args.source),read(args.target),Decimal(args.tolerance))
    (ROOT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    rows=[{k:v for k,v in r.items() if k not in ['source_rows','target_rows']} for r in result['records']]
    write_csv(ROOT/'review.csv',rows,list(rows[0]) if rows else ['reference','status'])
    print(json.dumps(result['meta']))
if __name__=='__main__': main()
