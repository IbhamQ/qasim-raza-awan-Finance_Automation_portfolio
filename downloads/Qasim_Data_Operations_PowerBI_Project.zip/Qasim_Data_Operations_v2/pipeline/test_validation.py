import unittest
from decimal import Decimal
from validate import validate, money
def row(ref='A',amount='10.00',currency='USD'):
    return dict(reference=ref,amount=amount,currency=currency,date='2026-10-01',region='East',row_number=2)
class Checks(unittest.TestCase):
    def test_exact(self): self.assertEqual(validate([row()],[row()])['meta']['matched'],1)
    def test_duplicate_not_summed(self):
        r=validate([row(),row()],[row(amount='20.00')])['records'][0]
        self.assertIsNone(r['source_amount']); self.assertIn('Duplicate key',r['reasons'])
    def test_tolerance(self):
        self.assertEqual(validate([row()],[row(amount='10.01')])['meta']['matched'],1)
        self.assertEqual(validate([row()],[row(amount='10.02')])['meta']['review'],1)
    def test_currency_never_joined(self): self.assertEqual(len(validate([row()],[row(currency='EUR')])['records']),2)
    def test_blank_quarantine(self): self.assertEqual(validate([row(ref='')],[])['meta']['quarantined_rows'],1)
    def test_invalid_money(self):
        for v in ['NaN','Infinity','','abc','1.234']: self.assertIsNone(money(v))
    def test_zero_and_negative(self):
        for v in ['0.00','-10.00']: self.assertEqual(validate([row(amount=v)],[row(amount=v)])['meta']['matched'],1)
    def test_invalid_date(self):
        a=row(); a['date']='2026-13-01'; self.assertEqual(validate([a],[row()])['meta']['review'],1)
    def test_missing_and_normalization(self):
        self.assertEqual(validate([row(ref=' a ')],[row()])['meta']['matched'],1)
        self.assertIn('Source only',validate([row()],[])['records'][0]['reasons'])
    def test_negative_tolerance(self):
        with self.assertRaises(ValueError): validate([],[],Decimal('-1'))
if __name__=='__main__': unittest.main()
