# Qasim Raza Awan | Data Operations and Reconciliation

## Revision 2

The first refresh attempt reported a cyclic-reference error. All nine data queries have been rewritten as independent typed table literals, with no references to other queries. Standalone query definitions are included in the PowerQuery folder. This removes query dependencies, but the revised refresh still needs verification in Desktop.

Close the first version and extract this revision into a fresh folder before opening its PBIP file. Do not merge it into the existing Desktop project folder or reuse the old local cache.

## Open in Power BI Desktop

1. Extract the entire ZIP to an ordinary local folder. Keep both the Report and SemanticModel folders beside the PBIP file.
2. Double click **Qasim_Data_Operations.pbip**. Do not import the ZIP or CSV through Get data.
3. Click **Home → Refresh** to populate the embedded Import model. No external account, gateway or data path is needed for this synthetic snapshot.
4. Open the four page tabs. On **03 | Operational trends**, select **USD** or **EUR** in Currency. Monetary totals intentionally remain blank when multiple currencies are selected.
5. To produce a single-file report, use **File → Save As → Power BI report (.pbix)** after a successful refresh.

If your Desktop version requests it, enable Power BI Project and enhanced report-format preview features under File → Options and settings → Options → Preview features, restart and reopen. Use a current Power BI Desktop version.

## What is included

- Four preconfigured native Power BI report pages: Data quality, Exception workbench, Operational trends, Controls and evidence.
- 55 native visuals including data-bound cards, charts, slicers and tables; no HTML dashboard substituted for a Power BI report.
- Nine Import model tables, five relationships and 17 DAX measures.
- Embedded Power Query data: portable and safe to share; records are wholly synthetic.
- Original CSVs, Python validation source, ten unit tests, JSON/CSV outputs and readable DAX definitions.

## Definitions and controls

The match grain is normalized reference plus currency. Keys with missing references or currencies are quarantined outside the match denominator. Duplicate keys are not added together; their amounts remain blank. Only one-to-one records with numeric amounts and supported currencies contribute to comparable monetary totals. Source-only, target-only and invalid records remain available for investigation.

Match tolerance is 0.01 inclusive. Amounts use at most two decimal places and must be finite. Dates must be ISO calendar dates; permitted regions are East, Central and West. USD and EUR are supported. A currency mismatch creates separate one-sided keys. Amounts from different currencies are never added together. Period and region are attributed to the source record when present; metadata disagreement is flagged.

Issue flags are individual rule failures and may exceed the number of affected keys. The Controls page source-row counts and quarantine table are global input controls rather than slicer-adjusted match statistics. Monetary differences are not estimates of total financial exposure.

## Expected initial results

| Control | Expected value |
| --- | ---: |
| Source input rows | 122 |
| Target input rows | 116 |
| Distinct nonblank match keys | 122 |
| Matched keys | 106 |
| Keys for review | 16 |
| Match rate | 86.9% |
| Quarantined source rows | 1 |

## Refresh and reproduction

The model refresh reprocesses its embedded synthetic snapshot. It is not connected to a live Fabric workspace. To regenerate the supplied pipeline outputs, run `python validate.py --demo` inside `pipeline`, then `python -m unittest discover -p 'test_*.py'`. To rebuild the embedded model and report definitions from those outputs, close the report in Desktop, then run `python build_report.py` from the extracted project folder. Preserve the included Report and SemanticModel folders. Reopen and refresh in Desktop after rebuilding.

## Verification status

The Python unit tests, source-to-output control totals, model field bindings, relationship cardinalities, visual geometry and Microsoft's report-definition validator were checked during creation. Native report rendering, DAX execution and refresh still require opening in Power BI Desktop; they could not be executed in the authoring environment. Report any Desktop error with its exact message so the file can be corrected. This is a native report project pending that final runtime check, not a claim of an independently verified production deployment.

## Portfolio attribution

Prepared for Qasim's portfolio with AI assistance, using synthetic data and reconciliation patterns relevant to his practical work. It contains no confidential employer/client records. It does not establish past production experience with Fabric or healthcare analytics.

Portfolio: https://qasimawan-finnovative-automations.vercel.app/
