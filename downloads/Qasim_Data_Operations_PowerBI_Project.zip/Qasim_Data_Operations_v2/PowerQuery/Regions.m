#table(
    type table [#"Region" = nullable text],
    {
    {"Central"},
    {"East"},
    {"West"}
    }
)