#table(
    type table [#"Key" = nullable text, #"Rule" = nullable text],
    {
    {"ORD-0010|USD", "Amount mismatch"},
    {"ORD-0020|EUR", "Duplicate key"},
    {"ORD-0025|USD", "Amount mismatch"},
    {"ORD-0030|USD", "Duplicate key"},
    {"ORD-0040|EUR", "Date mismatch"},
    {"ORD-0040|EUR", "Target: invalid date"},
    {"ORD-0050|USD", "Source: invalid amount"},
    {"ORD-0060|EUR", "Region mismatch"},
    {"ORD-0060|EUR", "Target: invalid region"},
    {"ORD-0070|GBP", "Target only"},
    {"ORD-0070|GBP", "Unsupported currency"},
    {"ORD-0070|USD", "Source only"},
    {"ORD-0115|USD", "Source only"},
    {"ORD-0116|EUR", "Source only"},
    {"ORD-0117|USD", "Source only"},
    {"ORD-0118|USD", "Source only"},
    {"ORD-0119|USD", "Source only"},
    {"ORD-0120|EUR", "Source only"},
    {"ORD-9999|USD", "Target only"}
    }
)