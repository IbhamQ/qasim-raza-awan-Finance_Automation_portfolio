#table(
    type table [#"Side" = nullable text, #"Row" = nullable number, #"Reference" = nullable text, #"Currency" = nullable text, #"Amount as received" = nullable text, #"Reason" = nullable text],
    {
    {"Source", 123, "", "USD", "100.00", "Missing reference or currency"}
    }
)