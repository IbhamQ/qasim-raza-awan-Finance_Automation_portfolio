#table(
    type table [#"Period" = nullable text],
    {
    {"2026-08"},
    {"2026-09"},
    {"2026-10"}
    }
)