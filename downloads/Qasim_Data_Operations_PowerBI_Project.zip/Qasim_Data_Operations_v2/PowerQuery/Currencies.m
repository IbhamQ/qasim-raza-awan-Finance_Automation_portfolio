#table(
    type table [#"Currency" = nullable text],
    {
    {"EUR"},
    {"GBP"},
    {"USD"}
    }
)