#table(
    type table [#"Status" = nullable text],
    {
    {"Matched"},
    {"Review"}
    }
)