"""Build the native PBIP report and embedded Import semantic model.
No HTML dashboard is used as a replacement for Power BI visuals.
"""
from pathlib import Path
import csv, json, shutil, uuid

ROOT=Path(__file__).resolve().parent
if not (ROOT/'Qasim_Data_Operations.pbip').exists(): ROOT=ROOT/'powerbi_dataops'
SRC=ROOT/'pipeline'
if not SRC.exists(): SRC=ROOT.parent/'portfolio-dataops/data-operations'
REPORT=ROOT/'Qasim_Data_Operations.Report'
MODEL=ROOT/'Qasim_Data_Operations.SemanticModel'
MODEL.mkdir(exist_ok=True)
data=json.loads((SRC/'results.json').read_text())
SCHEMA='https://developer.microsoft.com/json-schemas/fabric/item/report/definition/'
NAVY='#172B45'; TEAL='#237B70'; AMBER='#AF6D24'; MUTED='#64748B'; BG='#F4F6F9'
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def uid():return uuid.uuid4().hex[:20]
def lit(v):
    text=('true' if v else 'false') if isinstance(v,bool) else str(v)+'D' if isinstance(v,(int,float)) else "'"+v.replace("'","''")+"'"
    return {'expr':{'Literal':{'Value':text}}}
def fill(v):return {'solid':{'color':lit(v)}}
def props(**kw):return [{'properties':kw}]
def field(table,name,measure=False):
    return {'field':{'Measure' if measure else 'Column':{'Expression':{'SourceRef':{'Entity':table}},'Property':name}},'queryRef':table+'.'+name,'nativeQueryRef':name}
def col(t,n):return field(t,n)
def measure(n):return field('Reconciliation',n,True)

# Portable sources are embedded as JSON arrays in native Power Query partitions.
# Data refresh needs no credentials, absolute file paths, external tenant or gateway.
def table(name,cols,rows,measures=None,hidden=False):
    # A typed #table literal has no let-step or shared-query dependencies.
    mtypes={'string':'nullable text','int64':'nullable number','double':'nullable number','boolean':'nullable logical'}
    def mliteral(v):
        if v is None:return 'null'
        if isinstance(v,bool):return 'true' if v else 'false'
        if isinstance(v,(int,float)):return str(v)
        return '"'+str(v).replace('#','#(#)').replace('"','""').replace('\n','#(lf)').replace('\r','#(cr)')+'"'
    fields=', '.join('#"'+n.replace('"','""')+'" = '+mtypes[t] for n,t in cols)
    literals=',\n'.join('    {'+', '.join(mliteral(v) for v in row)+'}' for row in rows)
    m=['#table(',f'    type table [{fields}],','    {',literals,'    }',')']
    querydir=ROOT/'PowerQuery';querydir.mkdir(exist_ok=True)
    (querydir/(name+'.m')).write_text('\n'.join(m),encoding='utf-8')
    result={'name':name,'columns':[{'name':n,'dataType':t,'sourceColumn':n,'summarizeBy':'none',**({'formatString':'#,0.00;(#,0.00);0.00'} if t=='double' else {})} for n,t in cols],
        'partitions':[{'name':name,'mode':'import','source':{'type':'m','expression':m}}]}
    if measures:result['measures']=measures
    if hidden:result['isHidden']=True
    return result
measures=[]
def dax(name,expression,fmt='#,0',desc=''):
    measures.append(dict(name=name,expression=expression,formatString=fmt,description=desc,displayFolder='Data operations'))
dax('Keys in scope','COUNTROWS(Reconciliation)',desc='Distinct reference and currency combinations, excluding quarantined blank keys.')
dax('Matched keys','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(Reconciliation[Status] = "Matched")), 0)')
dax('Keys for review','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(Reconciliation[Status] = "Review")), 0)')
dax('Match rate','DIVIDE([Matched keys], [Keys in scope])','0.0%')
dax('Issue flags','COALESCE(COUNTROWS(Issues), 0)',desc='A key can have several issue flags. This is not a count of affected keys.')
dax('Source only keys','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(Reconciliation[Target count] = 0)), 0)')
dax('Target only keys','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(Reconciliation[Source count] = 0)), 0)')
dax('Duplicate keys','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(FILTER(Reconciliation, Reconciliation[Source count] > 1 || Reconciliation[Target count] > 1))), 0)')
dax('Comparable keys','COALESCE(CALCULATE([Keys in scope], KEEPFILTERS(Reconciliation[Comparable] = TRUE())), 0)')
dax('Comparable source amount','IF(HASONEVALUE(Currencies[Currency]), CALCULATE(SUM(Reconciliation[Source amount]), KEEPFILTERS(Reconciliation[Comparable] = TRUE())), BLANK())','#,0.00', 'Only one-to-one keys with numeric values in supported currencies. Returns blank across multiple currencies.')
dax('Comparable target amount','IF(HASONEVALUE(Currencies[Currency]), CALCULATE(SUM(Reconciliation[Target amount]), KEEPFILTERS(Reconciliation[Comparable] = TRUE())), BLANK())','#,0.00')
dax('Net amount difference','IF(HASONEVALUE(Currencies[Currency]), [Comparable source amount] - [Comparable target amount], BLANK())','#,0.00;(#,0.00);0.00')
dax('Absolute amount difference','IF(HASONEVALUE(Currencies[Currency]), SUMX(FILTER(Reconciliation, Reconciliation[Comparable] = TRUE()), ABS(Reconciliation[Variance])), BLANK())','#,0.00', 'Absolute differences on comparable records. Not total financial exposure; one-sided and invalid records require separate investigation.')
dax('Quarantined rows','COUNTROWS(Quarantine)',desc='Global raw-source control; unaffected by reconciliation dimensions.')
dax('Source input rows','COUNTROWS(SourceRaw)',desc='Global raw-source control; unaffected by reconciliation dimensions.')
dax('Target input rows','COUNTROWS(TargetRaw)',desc='Global raw-source control; unaffected by reconciliation dimensions.')
dax('Currency context','IF(HASONEVALUE(Currencies[Currency]), SELECTEDVALUE(Currencies[Currency]), "Select one currency")','', 'Prevents accidental cross-currency aggregation.')

cols=[('Key','string'),('Reference','string'),('Currency','string'),('Region','string'),('Period','string'),('Status','string'),('Source count','int64'),('Target count','int64'),('Source amount','double'),('Target amount','double'),('Variance','double'),('Reasons','string'),('Source rows','string'),('Target rows','string'),('Comparable','boolean')]
rows=[];issues=[]
for r in data['records']:
    key=r['reference']+'|'+r['currency']
    comparable=r['source_count']==r['target_count']==1 and r['source_amount'] is not None and r['target_amount'] is not None and r['currency'] in ['USD','EUR']
    rows.append([key,r['reference'],r['currency'],r['region'],r['period'],r['status'],r['source_count'],r['target_count'],r['source_amount'],r['target_amount'],r['variance'],r['reasons'],', '.join(map(str,r['source_rows'])),', '.join(map(str,r['target_rows'])),comparable])
    for reason in filter(None,r['reasons'].split('; ')):issues.append([key,reason])
tables=[table('Reconciliation',cols,rows,measures),table('Issues',[('Key','string'),('Rule','string')],issues)]
for name,column,ix in [('Currencies','Currency',2),('Regions','Region',3),('Periods','Period',4),('Statuses','Status',5)]:
    tables.append(table(name,[(column,'string')],[[v] for v in sorted(set(row[ix] for row in rows))]))
for name,file in [('SourceRaw','source.csv'),('TargetRaw','target.csv')]:
    raw=list(csv.DictReader((SRC/file).open()))
    tables.append(table(name,[('Row','int64'),('Reference','string'),('Currency','string'),('Amount as received','string'),('Date as received','string'),('Region','string')],[[i,r['reference'],r['currency'],r['amount'],r['date'],r['region']] for i,r in enumerate(raw,2)]))
tables.append(table('Quarantine',[('Side','string'),('Row','int64'),('Reference','string'),('Currency','string'),('Amount as received','string'),('Reason','string')],[[r['side'],r['row_number'],r['reference'],r['currency'],r['amount'],'Missing reference or currency'] for r in data['quarantine']]))
relationships=[]
for name,column in [('Currencies','Currency'),('Regions','Region'),('Periods','Period'),('Statuses','Status')]:
    relationships.append(dict(name=str(uuid.uuid4()),fromTable='Reconciliation',fromColumn=column,toTable=name,toColumn=column,fromCardinality='many',toCardinality='one',crossFilteringBehavior='oneDirection'))
relationships.append(dict(name=str(uuid.uuid4()),fromTable='Issues',fromColumn='Key',toTable='Reconciliation',toColumn='Key',fromCardinality='many',toCardinality='one',crossFilteringBehavior='oneDirection'))
save(MODEL/'definition.pbism',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json','version':'4.0','settings':{}})
save(MODEL/'.platform',{'$schema':'https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json','metadata':{'type':'SemanticModel','displayName':'Qasim Data Operations'},'config':{'version':'2.0','logicalId':str(uuid.uuid4())}})
save(MODEL/'model.bim',{'name':'Qasim_Data_Operations','compatibilityLevel':1601,'model':{'culture':'en-US','defaultPowerBIDataSourceVersion':'powerBI_V3','sourceQueryCulture':'en-US','tables':tables,'relationships':relationships,'annotations':[{'name':'PBI_ProTooling','value':'["DevMode"]'}]}})

# Native PBIR report pages and data-bound visuals.
pagesdir=REPORT/'definition/pages'
for old in pagesdir.iterdir():
    if old.is_dir():shutil.rmtree(old)
pageids=[]; visual_count=0; page_visuals={}
def page(title):
    pid=uid();pageids.append(pid);page_visuals[pid]=[]
    save(pagesdir/pid/'page.json',{'$schema':SCHEMA+'page/2.1.0/schema.json','name':pid,'displayName':title,'displayOption':'FitToPage','height':900,'width':1440,'objects':{'background':props(color=fill(BG),transparency=lit(0))}})
    return pid
def visual(pid,kind,x,y,w,h,title=None,query=None,objects=None,bg='#FFFFFF'):
    global visual_count
    vid=uid();visual_count+=1
    v={'visualType':kind,'visualContainerObjects':{'background':props(show=lit(True),color=fill(bg),transparency=lit(0)), 'border':props(show=lit(False)), 'padding':props(left=lit(12),right=lit(12),top=lit(10),bottom=lit(10))}}
    if title:v['visualContainerObjects']['title']=props(show=lit(True),text=lit(title),fontColor=fill(NAVY),fontSize=lit(12),fontFamily=lit('Segoe UI Semibold'))
    else:v['visualContainerObjects']['title']=props(show=lit(False))
    if query:v['query']={'queryState':{role:{'projections':fields} for role,fields in query.items()}}
    if objects:v['objects']=objects
    out={'$schema':SCHEMA+'visualContainer/2.9.0/schema.json','name':vid,'position':{'x':x,'y':y,'width':w,'height':h,'z':visual_count,'tabOrder':visual_count},'visual':v}
    save(pagesdir/pid/'visuals'/vid/'visual.json',out);page_visuals[pid].append(out)
    return out
def text(pid,x,y,w,h,value,size=12,color=MUTED,bold=False):
    paragraphs=[{'textRuns':[{'value':line,'textStyle':{'fontFamily':'Segoe UI Semibold' if bold else 'Segoe UI','fontSize':str(size)+'px','color':color}}]} for line in value.split('\n')]
    v=visual(pid,'textbox',x,y,w,h,objects={'general':props(paragraphs=paragraphs)},bg=BG)
    v['visual']['visualContainerObjects']['padding']=props(left=lit(0),right=lit(0),top=lit(0),bottom=lit(0))
    save(pagesdir/pid/'visuals'/v['name']/'visual.json',v)
    return v
def header(pid,number,title,subtitle):
    text(pid,32,20,1200,28,'QASIM RAZA AWAN   /   DATA OPERATIONS PORTFOLIO   /   '+number,12,TEAL,True)
    text(pid,32,52,1350,50,title,30,NAVY,True)
    text(pid,32,105,1350,42,subtitle,14)
    text(pid,32,858,1360,26,'SYNTHETIC DATA  |  Aug–Oct 2026  |  Match grain: reference + currency  |  No employer or client records published',11)
def slicer(pid,x,table,column,width=210):
    return visual(pid,'slicer',x,155,width,86,query={'Values':[col(table,column)]},objects={'data':props(mode=lit('Dropdown')),'header':props(show=lit(True),text=lit(column))})
def card(pid,x,y,w,name,color=NAVY):
    return visual(pid,'card',x,y,w,114,query={'Values':[measure(name)]},objects={'labels':props(fontSize=lit(29),color=fill(color),labelDisplayUnits=lit(1)),'categoryLabels':props(show=lit(True),fontSize=lit(11),color=fill(MUTED))})
def chart(pid,kind,x,y,w,h,title,category,ys,series=None):
    q={'Category':[category],'Y':[measure(n) for n in ys]}
    if series:q['Series']=[series]
    v=visual(pid,kind,x,y,w,h,title,q)
    v['visual']['query']['sortDefinition']={'sort':[{'field':category['field'],'direction':'Ascending'}],'isDefaultSort':False}
    save(pagesdir/pid/'visuals'/v['name']/'visual.json',v)
    return v
def grid(pid,x,y,w,h,title,fields):
    return visual(pid,'tableEx',x,y,w,h,title,{'Values':fields},objects={'columnHeaders':props(fontSize=lit(10),fontColor=fill('#FFFFFF'),backColor=fill(NAVY),autoSizeColumnWidth=lit(True),wordWrap=lit(True)),'values':props(fontSize=lit(10),fontColorPrimary=fill(NAVY),fontColorSecondary=fill(NAVY),backColorPrimary=fill('#FFFFFF'),backColorSecondary=fill('#F0F4F7'),wordWrap=lit(True)),'total':props(totals=lit(False))})

p=page('01 | Data quality')
header(p,'01','Can the operational data be trusted?','Inspect completeness, one-to-one matching and rule failures before relying on the numbers.')
for x,t,c in [(32,'Periods','Period'),(258,'Regions','Region'),(484,'Currencies','Currency'),(710,'Statuses','Status')]:slicer(p,x,t,c)
for x,name,color in [(32,'Keys in scope',NAVY),(380,'Matched keys',TEAL),(728,'Keys for review',AMBER),(1076,'Match rate',TEAL)]:card(p,x,257,332,name,color)
chart(p,'clusteredBarChart',32,389,674,310,'Keys for review by region',col('Regions','Region'),['Keys for review'])
chart(p,'columnChart',722,389,686,310,'Matched and review keys by period',col('Periods','Period'),['Keys in scope'],col('Statuses','Status'))
text(p,32,721,1360,100,'READING THE SCORECARD\nMatch rate = matched keys ÷ distinct nonblank reference/currency keys. One raw row with a missing reference is quarantined separately. Duplicate records are never summed into an apparent match. Select a chart category to cross-filter the other visuals.',15)

p=page('02 | Exception workbench')
header(p,'02','Find the discrepancy. Trace the source.','Filter the register, inspect the rule flags and trace each key to its original CSV row numbers.')
for x,t,c in [(32,'Periods','Period'),(258,'Regions','Region'),(484,'Currencies','Currency'),(710,'Statuses','Status')]:slicer(p,x,t,c)
card(p,32,257,250,'Keys for review',AMBER);card(p,298,257,250,'Duplicate keys',AMBER);card(p,564,257,250,'Issue flags',AMBER)
text(p,838,263,566,100,'A key can trigger several rules. Issue flags can exceed affected keys. Blank amounts mean missing or invalid data, or duplicate records requiring review.',15)
grid(p,32,389,1376,440,'Reconciliation register · select Review in the Status slicer',[
    col('Reconciliation',n) for n in ['Reference','Currency','Region','Status','Source count','Target count','Source amount','Target amount','Variance','Reasons','Source rows','Target rows']])

p=page('03 | Operational trends')
header(p,'03','Compare like with like.','Monetary measures require a single currency and use only one-to-one records with valid numeric amounts.')
for x,t,c in [(32,'Currencies','Currency'),(258,'Periods','Period'),(484,'Regions','Region')]:slicer(p,x,t,c)
text(p,730,164,662,75,'Choose USD or EUR above to populate monetary visuals.\nMultiple currencies are deliberately not added together.',15,TEAL,True)
for x,name in [(32,'Comparable source amount'),(380,'Comparable target amount'),(728,'Net amount difference'),(1076,'Absolute amount difference')]:card(p,x,257,332,name)
chart(p,'clusteredColumnChart',32,389,846,310,'Comparable source and target amounts by period',col('Periods','Period'),['Comparable source amount','Comparable target amount'])
grid(p,894,389,514,310,'Completeness by period',[col('Periods','Period'),measure('Source only keys'),measure('Target only keys'),measure('Comparable keys')])
text(p,32,721,1360,102,'INTERPRETATION\nNet differences may offset. Absolute differences keep both directions visible. These measures exclude one-sided, duplicate and invalid-amount records; they are not a total exposure estimate. A currency change creates separate unmatched keys, rather than an unsafe cross-currency match.',15)

p=page('04 | Controls and evidence')
header(p,'04','The controls behind the dashboard.','A reproducible Python pipeline, inspectable source rows and explicit definitions support each reported result.')
for x,name in [(32,'Source input rows'),(496,'Target input rows'),(960,'Quarantined rows')]:card(p,x,155,448,name)
chart(p,'clusteredBarChart',32,293,674,310,'Rule failures · flags, not distinct keys',col('Issues','Rule'),['Issue flags'])
grid(p,722,293,686,168,'Quarantine · raw records outside the match denominator',[col('Quarantine',n) for n in ['Side','Row','Reference','Currency','Amount as received','Reason']])
text(p,722,478,686,134,'LINEAGE\nSource CSV + Target CSV → normalize keys → quarantine blanks → detect duplicates → validate formats → compare one-to-one records → classify exceptions → native Power BI model.',15)
text(p,32,627,674,200,'RULES AND LIMITS\nTolerance: 0.01, inclusive. Amounts allow at most two decimals. Dates must be ISO calendar dates. Supported currencies: USD and EUR. Valid regions: East, Central and West. Period and region use the source record when present; contradictory metadata is flagged.',14)
text(p,722,627,686,200,'DEMONSTRATION STATUS\nCreated with synthetic records, based on practical reconciliation patterns. The embedded snapshot refreshes without external credentials. It does not demonstrate a deployed Fabric pipeline or production client system. Raw source and target tables are available in Data view.\nPortfolio: qasimawan-finnovative-automations.vercel.app',14)

save(pagesdir/'pages.json',{'$schema':SCHEMA+'pagesMetadata/1.1.0/schema.json','pageOrder':pageids,'activePageName':pageids[0]})
# Custom restrained theme; retain scaffolded base theme and resources.
theme={'name':'QasimDataOps.json','dataColors':[TEAL,AMBER,'#477EA7','#8D6FA2','#6B8292'],'background':'#FFFFFF','foreground':NAVY,'tableAccent':TEAL,
    'textClasses':{'label':{'fontFace':'Segoe UI','fontSize':11,'color':NAVY},'title':{'fontFace':'Segoe UI Semibold','fontSize':13,'color':NAVY},'callout':{'fontFace':'Segoe UI Semibold','color':NAVY}}}
save(REPORT/'StaticResources/RegisteredResources/QasimDataOps.json',theme)
report=json.loads((REPORT/'definition/report.json').read_text())
report['themeCollection']['customTheme']={'name':'QasimDataOps.json','reportVersionAtImport':{'visual':'2.9.0','report':'3.3.0','page':'2.1.0'},'type':'RegisteredResources'}
report['resourcePackages']=[r for r in report['resourcePackages'] if r['type']!='RegisteredResources']
report['resourcePackages'].append({'name':'RegisteredResources','type':'RegisteredResources','items':[{'name':'QasimDataOps.json','path':'QasimDataOps.json','type':'CustomTheme'}]})
save(REPORT/'definition/report.json',report)

# Check all visual fields bind to real model objects and no rectangles overlap.
inventory={t['name']:{c['name'] for c in t['columns']}|{m['name'] for m in t.get('measures',[])} for t in tables}
for pid,visuals in page_visuals.items():
    for v in visuals:
        pos=v['position'];assert pos['x']>=0 and pos['y']>=0 and pos['x']+pos['width']<=1440 and pos['y']+pos['height']<=900
        for role in v['visual'].get('query',{}).get('queryState',{}).values():
            for projection in role['projections']:
                f=next(iter(projection['field'].values()));assert f['Property'] in inventory[f['Expression']['SourceRef']['Entity']]
    for i,a in enumerate(visuals):
        a=a['position']
        for b in visuals[i+1:]:
            b=b['position'];assert min(a['x']+a['width'],b['x']+b['width'])<=max(a['x'],b['x']) or min(a['y']+a['height'],b['y']+b['height'])<=max(a['y'],b['y'])
assets=ROOT/'pipeline';assets.mkdir(exist_ok=True)
if SRC.resolve()!=assets.resolve():
    for name in ['validate.py','test_validation.py','source.csv','target.csv','results.json','review.csv']:shutil.copy2(SRC/name,assets/name)
(ROOT/'Measures.dax').write_text('\n\n'.join(m['name']+' =\n'+m['expression'] for m in measures))
print(json.dumps({'pages':len(pageids),'visuals':visual_count,'tables':len(tables),'measures':len(measures),'relationships':len(relationships),'bindings_and_bounds':'passed'}))
